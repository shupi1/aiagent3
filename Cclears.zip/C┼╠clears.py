import os
import shutil
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import winshell
from pathlib import Path
import platform
import ctypes
import sys

# 检查是否以管理员权限运行
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

# 如果不是管理员，请求提升权限
if not is_admin():
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas", sys.executable, " ".join(sys.argv), None, 1
    )
    sys.exit()

class CDriveCleaner:
    def __init__(self, root):
        self.root = root
        self.root.title("C盘清理精灵")
        self.root.geometry("800x600")
        self.root.resizable(True, True)
        
        # 设置中文字体
        self.style = ttk.Style()
        self.style.configure("Treeview.Heading", font=('SimHei', 10, 'bold'))
        self.style.configure("Treeview", font=('SimHei', 10))
        
        # 垃圾文件列表
        self.junk_files = []
        self.total_size = 0
        
        # 创建界面
        self.create_widgets()
        
        # 常见的垃圾文件路径
        self.junk_paths = [
            # 系统临时文件
            os.path.join(os.environ.get('TEMP', ''), '*'),
            # 用户临时文件
            os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Temp', '*'),
            # 浏览器缓存 - Chrome
            os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Google', 'Chrome', 'User Data', 'Default', 'Cache', '*'),
            # 浏览器缓存 - Edge
            os.path.join(os.path.expanduser('~'), 'AppData', 'Local', 'Microsoft', 'Edge', 'User Data', 'Default', 'Cache', '*'),
            # 下载文件夹中的临时文件
            os.path.join(os.path.expanduser('~'), 'Downloads', '*.tmp'),
            os.path.join(os.path.expanduser('~'), 'Downloads', '*.crdownload'),
            # 回收站
            # 注意：回收站操作需要特殊处理
        ]
        
        # 推荐删除的文件类型
        self.recommended_extensions = ['.tmp', '.log', '.bak', '.crdownload', '.old']

    def create_widgets(self):
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="10")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 顶部信息栏
        info_frame = ttk.Frame(main_frame)
        info_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.total_label = ttk.Label(info_frame, text="C盘总大小: 扫描中...")
        self.total_label.pack(side=tk.LEFT, padx=5)
        
        self.free_label = ttk.Label(info_frame, text="可用空间: 扫描中...")
        self.free_label.pack(side=tk.LEFT, padx=5)
        
        self.junk_label = ttk.Label(info_frame, text="可释放空间: 0 MB")
        self.junk_label.pack(side=tk.LEFT, padx=5)
        
        # 按钮区域
        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill=tk.X, pady=(0, 10))
        
        self.scan_button = ttk.Button(button_frame, text="扫描垃圾文件", command=self.scan_junk_files)
        self.scan_button.pack(side=tk.LEFT, padx=5)
        
        self.select_all_button = ttk.Button(button_frame, text="全选", command=self.select_all)
        self.select_all_button.pack(side=tk.LEFT, padx=5)
        
        self.select_recommended_button = ttk.Button(button_frame, text="推荐删除", command=self.select_recommended)
        self.select_recommended_button.pack(side=tk.LEFT, padx=5)
        
        self.deselect_all_button = ttk.Button(button_frame, text="取消选择", command=self.deselect_all)
        self.deselect_all_button.pack(side=tk.LEFT, padx=5)
        
        self.clean_button = ttk.Button(button_frame, text="一键清理", command=self.clean_selected)
        self.clean_button.pack(side=tk.RIGHT, padx=5)
        
        # 列表区域
        list_frame = ttk.Frame(main_frame)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建滚动条
        scrollbar = ttk.Scrollbar(list_frame)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 创建树状视图
        columns = ("select", "name", "size", "path", "recommended")
        self.tree = ttk.Treeview(list_frame, columns=columns, show="headings", yscrollcommand=scrollbar.set)
        
        # 设置列宽和标题
        self.tree.column("select", width=50, anchor=tk.CENTER)
        self.tree.column("name", width=150, anchor=tk.W)
        self.tree.column("size", width=100, anchor=tk.E)
        self.tree.column("path", width=350, anchor=tk.W)
        self.tree.column("recommended", width=80, anchor=tk.CENTER)
        
        self.tree.heading("select", text="选择")
        self.tree.heading("name", text="文件名")
        self.tree.heading("size", text="大小")
        self.tree.heading("path", text="路径")
        self.tree.heading("recommended", text="推荐")
        
        self.tree.pack(fill=tk.BOTH, expand=True)
        scrollbar.config(command=self.tree.yview)
        
        # 绑定复选框点击事件
        self.tree.bind('<Button-1>', self.on_tree_click)
        
        # 状态栏
        self.status_var = tk.StringVar()
        self.status_var.set("就绪")
        status_bar = ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor=tk.W)
        status_bar.pack(side=tk.BOTTOM, fill=tk.X)

    def on_tree_click(self, event):
        # 处理复选框点击
        region = self.tree.identify_region(event.x, event.y)
        if region == "cell":
            column = int(self.tree.identify_column(event.x).replace('#', ''))
            if column == 1:  # 第一列是选择列
                item = self.tree.identify_row(event.y)
                if item:
                    current_value = self.tree.item(item, "values")[0]
                    new_value = "✓" if current_value != "✓" else ""
                    values = list(self.tree.item(item, "values"))
                    values[0] = new_value
                    self.tree.item(item, values=values)

    def scan_junk_files(self):
        # 清空现有列表
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        self.junk_files = []
        self.total_size = 0
        self.status_var.set("正在扫描垃圾文件...")
        self.root.update()
        
        # 更新磁盘信息
        self.update_drive_info()
        
        # 扫描垃圾文件
        for path_pattern in self.junk_paths:
            try:
                # 分离目录和模式
                dir_path = os.path.dirname(path_pattern)
                file_pattern = os.path.basename(path_pattern)
                
                if os.path.exists(dir_path):
                    for root, dirs, files in os.walk(dir_path):
                        for file in files:
                            # 简单的模式匹配
                            if file_pattern == '*' or file.endswith(tuple(file_pattern.split('*')[1:])):
                                file_path = os.path.join(root, file)
                                self.process_file(file_path)
                                
            except Exception as e:
                print(f"扫描错误: {e}")
        
        # 添加回收站信息
        try:
            recycle_bin_size = self.get_recycle_bin_size()
            if recycle_bin_size > 0:
                self.junk_files.append({
                    'path': '回收站',
                    'name': '回收站文件',
                    'size': recycle_bin_size,
                    'is_recommended': True,
                    'is_recycle_bin': True
                })
                self.total_size += recycle_bin_size
        except Exception as e:
            print(f"获取回收站信息错误: {e}")
        
        # 显示扫描结果
        self.display_junk_files()
        
        # 更新状态
        self.status_var.set(f"扫描完成，共发现 {len(self.junk_files)} 个垃圾文件")
        self.junk_label.config(text=f"可释放空间: {self.format_size(self.total_size)}")

    def process_file(self, file_path):
        try:
            # 获取文件大小
            file_size = os.path.getsize(file_path)
            
            # 只处理大于0字节的文件
            if file_size <= 0:
                return
                
            # 检查是否是推荐删除的文件
            file_ext = os.path.splitext(file_path)[1].lower()
            is_recommended = file_ext in self.recommended_extensions
            
            file_name = os.path.basename(file_path)
            
            self.junk_files.append({
                'path': file_path,
                'name': file_name,
                'size': file_size,
                'is_recommended': is_recommended,
                'is_recycle_bin': False
            })
            
            self.total_size += file_size
            
            # 每100个文件更新一次界面，避免界面卡顿
            if len(self.junk_files) % 100 == 0:
                self.status_var.set(f"已发现 {len(self.junk_files)} 个垃圾文件，总大小: {self.format_size(self.total_size)}")
                self.root.update()
                
        except Exception as e:
            # 忽略无法访问的文件
            pass

    def get_recycle_bin_size(self):
        # 获取回收站大小
        try:
            total_size = 0
            for drive in winshell.recycle_bin():
                total_size += drive.size()
            return total_size
        except:
            return 0

    def display_junk_files(self):
        # 按文件大小排序，从大到小
        self.junk_files.sort(key=lambda x: x['size'], reverse=True)
        
        for file_info in self.junk_files:
            recommended = "推荐" if file_info['is_recommended'] else ""
            # 默认选中推荐的文件
            selected = "✓" if file_info['is_recommended'] else ""
            
            self.tree.insert("", tk.END, values=(
                selected,
                file_info['name'],
                self.format_size(file_info['size']),
                file_info['path'],
                recommended
            ))

    def update_drive_info(self):
        # 更新C盘信息
        try:
            if platform.system() == "Windows":
                drive = "C:\\"
                free_bytes = ctypes.c_ulonglong(0)
                total_bytes = ctypes.c_ulonglong(0)
                
                ctypes.windll.kernel32.GetDiskFreeSpaceExW(
                    ctypes.c_wchar_p(drive),
                    None,
                    ctypes.pointer(total_bytes),
                    ctypes.pointer(free_bytes)
                )
                
                total_size = total_bytes.value
                free_size = free_bytes.value
                
                self.total_label.config(text=f"C盘总大小: {self.format_size(total_size)}")
                self.free_label.config(text=f"可用空间: {self.format_size(free_size)}")
        except Exception as e:
            print(f"获取磁盘信息错误: {e}")

    def format_size(self, size_bytes):
        # 格式化文件大小显示
        units = ['B', 'KB', 'MB', 'GB', 'TB']
        unit_index = 0
        
        while size_bytes >= 1024 and unit_index < len(units) - 1:
            size_bytes /= 1024
            unit_index += 1
            
        return f"{size_bytes:.2f} {units[unit_index]}"

    def select_all(self):
        # 全选
        for item in self.tree.get_children():
            values = list(self.tree.item(item, "values"))
            values[0] = "✓"
            self.tree.item(item, values=values)

    def deselect_all(self):
        # 取消全选
        for item in self.tree.get_children():
            values = list(self.tree.item(item, "values"))
            values[0] = ""
            self.tree.item(item, values=values)

    def select_recommended(self):
        # 选择推荐的文件
        for i, item in enumerate(self.tree.get_children()):
            if self.junk_files[i]['is_recommended']:
                values = list(self.tree.item(item, "values"))
                values[0] = "✓"
                self.tree.item(item, values=values)
            else:
                values = list(self.tree.item(item, "values"))
                values[0] = ""
                self.tree.item(item, values=values)

    def clean_selected(self):
        # 清理选中的文件
        selected_count = 0
        cleaned_size = 0
        
        # 先确认
        if not messagebox.askyesno("确认清理", "确定要删除选中的文件吗？此操作不可恢复！"):
            return
            
        self.status_var.set("正在清理文件...")
        self.root.update()
        
        # 遍历所有项目
        for i, item in enumerate(self.tree.get_children()):
            values = self.tree.item(item, "values")
            if values[0] == "✓":  # 选中的项目
                file_info = self.junk_files[i]
                try:
                    if file_info['is_recycle_bin']:
                        # 清空回收站
                        winshell.recycle_bin().empty(confirm=False, show_progress=False)
                        selected_count += 1
                        cleaned_size += file_info['size']
                    else:
                        # 删除文件
                        if os.path.exists(file_info['path']):
                            if os.path.isfile(file_info['path']):
                                os.remove(file_info['path'])
                            elif os.path.isdir(file_info['path']):
                                shutil.rmtree(file_info['path'])
                            selected_count += 1
                            cleaned_size += file_info['size']
                            
                except Exception as e:
                    print(f"删除错误 {file_info['path']}: {e}")
                    messagebox.showerror("删除错误", f"无法删除 {file_info['name']}: {str(e)}")
            
            # 每删除10个文件更新一次状态
            if selected_count > 0 and selected_count % 10 == 0:
                self.status_var.set(f"已清理 {selected_count} 个文件，释放空间: {self.format_size(cleaned_size)}")
                self.root.update()
        
        # 清理完成后重新扫描
        self.scan_junk_files()
        
        # 显示结果
        messagebox.showinfo("清理完成", f"成功清理 {selected_count} 个文件，释放空间: {self.format_size(cleaned_size)}")
        self.status_var.set(f"清理完成，成功清理 {selected_count} 个文件")

if __name__ == "__main__":
    # 确保程序以管理员权限运行
    if not is_admin():
        sys.exit(1)
        
    root = tk.Tk()
    app = CDriveCleaner(root)
    root.mainloop()
